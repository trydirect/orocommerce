<?php

namespace Oro\Bridge\CalendarCommerce;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OroCalendarCommerceBridgeBundle extends Bundle
{
}
