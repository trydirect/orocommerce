<?php

namespace Oro\Bundle\AlternativeCheckoutBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

/**
 * Bundle entry point
 */
class OroAlternativeCheckoutBundle extends Bundle
{
}
