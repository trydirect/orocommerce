<?php

namespace Oro\Bundle\ApplicationBundle\Tests\Unit\Stub;

class TestEntity
{
}
