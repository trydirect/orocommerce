<?php

namespace Oro\Bundle\ApplicationBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OroApplicationBundle extends Bundle
{
}
