# Default Product Options

## General Information

The **Default Product Options** section is displayed on the create or edit pages of a particular master catalog category. The section contains the **Unit of Quantity** field that is shown by default in the product details page in the storefront, and the **Precision** field for the quantity that a user may order or add into the shopping list.

If both the unit of quantity and precision are specified, then all new products in this category will have these values preselected during creation.
