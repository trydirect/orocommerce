<?php

namespace Oro\Bundle\CatalogBundle\Model\Exception;

class InvalidArgumentException extends \InvalidArgumentException
{
}
