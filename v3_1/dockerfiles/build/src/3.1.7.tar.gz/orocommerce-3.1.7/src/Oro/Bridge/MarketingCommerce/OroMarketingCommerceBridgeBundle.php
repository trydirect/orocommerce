<?php

namespace Oro\Bridge\MarketingCommerce;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OroMarketingCommerceBridgeBundle extends Bundle
{
}
