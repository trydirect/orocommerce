# OroMarketingCommerceBridgeBundle

OroMarketingCommerceBridgeBundle is a bridge that integrates features of the marketing package into the OroCommerce applications.

The bundle redefines security firewall **tracking_data** to enable OroCommerce applications to receive marketing tracking data.
