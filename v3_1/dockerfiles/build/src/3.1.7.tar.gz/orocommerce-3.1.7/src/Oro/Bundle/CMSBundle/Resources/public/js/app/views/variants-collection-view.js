define(function(require) {
    'use strict';

    var VariantsCollectionView;
    var FieldsGroupsCollectionView = require('oroform/js/app/views/fields-groups-collection-view');

    VariantsCollectionView = FieldsGroupsCollectionView.extend({
        PRIMARY_FILED_SELECTOR: '[name$="[default]"]',

        events: {
            'click [name$="[default]"]': 'onPrimaryClick',
            'change >*': 'onChangeInFiledGroup'
        },

        /**
         * @inheritDoc
         */
        constructor: function VariantsCollectionView() {
            VariantsCollectionView.__super__.constructor.apply(this, arguments);
        }
    });

    return VariantsCollectionView;
});
