# OroAlternativeCheckoutBundle

OroAlternativeCheckoutBundle adds seller approval steps to the checkout workflow in the OroCommerce storefront if the order amount exceeds the order approval threshold value set by an application administrator in the alternative checkout workflow configuration UI.

Note: The checkout workflow in the OroCommerce storefront helps gather necessary information from the customer when they are creating a new order.
