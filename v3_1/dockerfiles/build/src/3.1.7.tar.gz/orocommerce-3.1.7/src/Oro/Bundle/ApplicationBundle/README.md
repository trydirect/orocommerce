# OroApplicationBundle

OroApplicationBundle is deprecated and will be removed in version 3.0. Please, do not use this bundle.

The bundle is used to provide functionality necessary to run multiple Symfony applications on the same codebase.
