- [CheckoutBundle](#checkoutbundle)

CheckoutBundle
--------------
* Consider that 'b2b_flow_checkout_with_consents' workflow will not be available anymore as well as all related started checkouts